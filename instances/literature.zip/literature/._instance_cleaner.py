import json
import pandas as pd
import argparse

def instance_rename(original_name):
    # Example: n_L7_b
    parts = original_name.split('_')
    return f"L{parts[2].upper()}{parts[1][1]}" 

    
# Parse command line arguments
parser = argparse.ArgumentParser(description="Process instance files.")
parser.add_argument("--instance_path", type=str, required=True, help="Path to the instance file.")
parser.add_argument("--output_path", type=str, required=True, help="Path to save the cleaned instance file.")
args = parser.parse_args()


# Extract the instance name from the file path
instance_name = args.instance_path.split("/")[-1].split(".")[0]
# Rename the instance
renamed_instance = instance_rename(instance_name)
# Load the instance data
with open(args.instance_path, 'r') as file:
    instance_data = json.load(file)
# Clean the instance data
instance_data["e"] = "NA"
instance_data["w"] = "NA"
instance_data["z"] = "NA"
instance_data["r"] = "NA"
if "S" in instance_data:
    del instance_data["S"]
# Save the cleaned instance data to a new file
with open(f'{args.output_path}/{renamed_instance}.json', 'w') as file:
    json.dump(instance_data, file, indent=4)
